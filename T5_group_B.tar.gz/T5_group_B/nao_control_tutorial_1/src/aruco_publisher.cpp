#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <aruco/aruco.h>
#include <iostream>
#include <opencv2/videoio.hpp>
#include <opencv2/video.hpp>
#include "std_msgs/Float32MultiArray.h"

using namespace cv;
using namespace std;

ros::Publisher aruco_pos_pub;

Mat detectMarker(Mat inputImage)
{
    //// Load camera parameters
    // create a variable in the class
    aruco::CameraParameters TheCameraParameters;

    // load the parameter matrix in the constructor
    Mat dist(1,5,CV_32FC1);
    dist.at<float>(0,0)=-0.066494;
    dist.at<float>(0,1)=0.095481;
    dist.at<float>(0,2)=-0.000279;
    dist.at<float>(0,3)=0.002292;
    dist.at<float>(0,4)=0.000000;

    Mat cameraP(3,3,CV_32FC1);
    cameraP.at<float>(0,0)=551.543059;
    cameraP.at<float>(0,1)=0.000000;
    cameraP.at<float>(0,2)=327.382898;
    cameraP.at<float>(1,0)=0.000000;
    cameraP.at<float>(1,1)=553.736023;
    cameraP.at<float>(1,2)=225.026380;
    cameraP.at<float>(2,0)=0.000000;
    cameraP.at<float>(2,1)=0.000000;
    cameraP.at<float>(2,2)=1.000000;

    TheCameraParameters.setParams(cameraP,dist,Size(640,480));
    TheCameraParameters.resize( Size(640,480) );

    Mat imageCopy;
    inputImage.copyTo(imageCopy);

    aruco::MarkerDetector Detector;
    vector<aruco::Marker> markers;
    float marker_size = 0.06;
    Detector.detect(inputImage, markers, TheCameraParameters, marker_size);

    std_msgs::Float32MultiArray aruco_pos;

    if (markers.size()>0)
    {
        float x,y,z;
        for(size_t i=0;i<markers.size();i++){
            cout << "3D position of Marker " << markers[i].id << ":\n";
            cout << markers[i].Tvec << "\n";
            x = markers[i].Tvec.at<float>(0,0);
            y = markers[i].Tvec.at<float>(0,1);
            z = markers[i].Tvec.at<float>(0,2);
            //draw  markers in the image
            markers[i].draw(imageCopy, Scalar(0,0,255), 2);
            // aruco::CvDrawingUtils::draw3dAxis(imageCopy,markers[i],TheCameraParameters);
        }
        aruco_pos.data.push_back(x);
        aruco_pos.data.push_back(y);
        aruco_pos.data.push_back(z);
        aruco_pos_pub.publish(aruco_pos);
    }
    return imageCopy;
}

void topCameraCallback(const sensor_msgs::ImageConstPtr& msg){
    try
    {
        // Convert msg to opencv format
        Mat top_cam;
        top_cam = cv_bridge::toCvShare(msg, "bgr8")->image;

        Mat marker_image;
        marker_image = detectMarker(top_cam);
        namedWindow("3D marker position");
        imshow("3D marker position", marker_image);
        char k = waitKey(30);
        if(k=='s')
            ros::shutdown();
    }
    catch (cv_bridge::Exception& e){
        ROS_ERROR("Could not convert from '%s' to 'bgr8'.", msg->encoding.c_str());
    }
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "tutorial_4");
    ros::NodeHandle nh;
    image_transport::ImageTransport it(nh);
    image_transport::Subscriber top_sub = it.subscribe("/nao_robot/camera/top/camera/image_raw", 1, topCameraCallback);
    aruco_pos_pub = nh.advertise<std_msgs::Float32MultiArray>("/aruco_position", 1);
    ros::spin();
    destroyAllWindows();
}