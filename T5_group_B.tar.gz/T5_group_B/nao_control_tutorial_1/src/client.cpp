#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>
#include <ros/ros.h>
#include "sensor_msgs/JointState.h"
#include "nao_control_tutorial_1/MoveJoints.h"
#include <string.h>
#include "std_msgs/Float32MultiArray.h"
using namespace std;

class Nao_control
{
public:
    char excercise='0'; // Change to 1, for the excercise 1.4, to 2 for excercise 2.2, to 3 for excercise 3
    char tracking_method='0'; // Change to 1 for the setAngles tracking and 2 for the angleInterpolation tracking
    float current_head_yaw;
    float current_head_pitch;


    // ros handler
    ros::NodeHandle nh_;

    // subscriber to joint states
    ros::Subscriber sensor_data_sub;

    // subscriber to aruco marker position
    ros::Subscriber aruco_pos_sub;

    // client node
    ros::ServiceClient client;

    Nao_control()
    {
        sensor_data_sub=nh_.subscribe("/joint_states",1, &Nao_control::sensorCallback, this);
        aruco_pos_sub=nh_.subscribe("/aruco_position",1, &Nao_control::arucoCallback, this);
        client = nh_.serviceClient<nao_control_tutorial_1::MoveJoints>("move_joints");
    }
    ~Nao_control()
    {
    }

    //handler for joint states
    void sensorCallback(const sensor_msgs::JointState::ConstPtr& jointState)
    {
        // ROS_INFO("Recieved a joint state message:\n");
        vector<string> name_vec{jointState->name};
        int num_of_joints = name_vec.size();

        string yaw_name = "HeadYaw"; 
        string pitch_name = "HeadPitch";
        for (int i=0; i<num_of_joints; i++)
        {
            if(yaw_name.compare(jointState->name[i])==0)
            {
                current_head_yaw = jointState->position[i] * (180.0/3.1415926);
            }
            if(pitch_name.compare(jointState->name[i])==0)
            {
                current_head_pitch = jointState->position[i] * (180.0/3.1415926);
            }
            //cout << "yaw:" << current_head_yaw << "\n" << "pitch:" <<current_head_pitch << "\n";
        }
    }


// TODO: create function for each task
    
    // Exercise: 4.1 move robot arms
    void moveArm_up()
    {
        nao_control_tutorial_1::MoveJoints srv;
        srv.request.method = 1;
        srv.request.chains.push_back("LArm");
        srv.request.names.push_back("LShoulderPitch");
        srv.request.angles.push_back(-90.0);
        srv.request.chains.push_back("RArm");
        srv.request.names.push_back("RShoulderPitch");
        srv.request.angles.push_back(-90.0);
        srv.request.fractionMaxSpeed = 0.2;
        if (client.call(srv))
        {
            // cout << srv.response.resp_string << "\n";
            ROS_INFO_STREAM(srv.response.resp_string);
        }
        else
        {
            ROS_ERROR("Failed to call service move_joints");
        }
    }

    // Exercise: 4.2 move shoulder
    void moveShoulder()
    {
        nao_control_tutorial_1::MoveJoints srv;
        srv.request.method = 2;
        srv.request.chains.push_back("LArm");
        srv.request.names.push_back("LShoulderRoll");
        srv.request.angles.push_back(30.0);
        srv.request.times.push_back(2.0);
        srv.request.names.push_back("LShoulderPitch");
        srv.request.angles.push_back(0.0);
        srv.request.times.push_back(1.0);
        srv.request.isAbsolute = true;
        if (client.call(srv))
        {
            // cout << srv.response.resp_string << "\n";
            ROS_INFO_STREAM(srv.response.resp_string);
        }
        else
        {
            ROS_ERROR("Failed to call service move_joints");
        }
    }


    void moveHead(int method, float pitch, float yaw)
    {
        nao_control_tutorial_1::MoveJoints srv;
        //cout << "nyaw:" << yaw << "\n" << "pitch:" <<pitch << "\n";
        
        srv.request.method = method;
        srv.request.chains.push_back("Head");
        srv.request.names.push_back("HeadPitch");
        srv.request.angles.push_back(pitch);
        srv.request.names.push_back("HeadYaw");
        srv.request.angles.push_back(yaw);
        if(method == 1)
        {
            srv.request.fractionMaxSpeed = 0.2;
        }
        else
        {   
            srv.request.times.push_back(0.5);
            srv.request.times.push_back(0.5);
            srv.request.isAbsolute = true;  
        }
                
        if (client.call(srv))
        {
            // cout << srv.response.resp_string << "\n";
            ROS_INFO_STREAM(srv.response.resp_string);
        }
        else
        {
            ROS_ERROR("Failed to call service move_joints");
        }
    }

    void arucoCallback(const std_msgs::Float32MultiArray::ConstPtr& marker_msg)
    {
        float headYawMax = 119.5;
        float headYawMin = -119.5;
        float headPitchMax = 29.5;
        float headPitchMin = -38.5;

        float x,y,z;
        x=marker_msg->data[0];
        y=marker_msg->data[1];
        z=marker_msg->data[2];

        // float error_x = x/z + 0.707/2;
        // float error_y = y/z + 0.707/2;
        
        float error_x = (x+0.07)/z;
        float error_y = (y+0.05)/z;

        float k = 10;

        float new_head_yaw, new_head_pitch;

        new_head_yaw = current_head_yaw - k*error_x;
        new_head_pitch = current_head_pitch + k*error_y;

        // cout << "current_yaw:" << current_head_yaw << "\n" << "current_pitch:" <<current_head_pitch << "\n";       
        // cout << "error_yaw:" << error_x << "\n" << "error_pitch:" <<error_y << "\n";
        // cout << "new_yaw:" << new_head_yaw << "\n" << "new_pitch:" <<new_head_pitch << "\n";
        

        // check angle limits
        if(new_head_yaw > headYawMax)
        {
            new_head_yaw = headYawMax;
        }
        if(new_head_yaw < headYawMin)
        {
            new_head_yaw = headYawMin;
        }

        if(new_head_pitch > headPitchMax)
        {
            new_head_pitch = headPitchMax;
        }
        if(new_head_pitch < headPitchMin)
        {
            new_head_pitch = headPitchMin;
        }

        //cout << "ex: " << excercise << "\ntrack: "<< tracking_method << "\n";
        if(excercise=='3'){
            if(tracking_method=='1')
                moveHead(1, new_head_yaw, new_head_pitch);
            if(tracking_method=='2')
                moveHead(2, new_head_yaw, new_head_pitch);
        }
    }
};

int main(int argc, char** argv)

{
    ros::init(argc, argv, "nao_tutorial_control_1");

    Nao_control ic;
    ic.excercise=argv[1][0];
    ic.tracking_method=argv[2][0];
    if(ic.excercise=='1')
        ic.moveArm_up();
    if(ic.excercise=='2')
        ic.moveShoulder();

    ros::spin();
    return 0;

}
