#!/usr/bin/env python
import rospy
import time
import almath
import sys
from naoqi import ALProxy
from nao_control_tutorial_1.srv import MoveJoints
motionProxy = None

def move_joint_handle(req):
    names  = req.names
    angles = [a * almath.TO_RAD for a in req.angles]
    chains = req.chains

    motionProxy.setStiffnesses(chains, 1.0)

    if req.method == 1:
        # print(angles)
        fractionMaxSpeed = req.fractionMaxSpeed
        motionProxy.setAngles(names, angles, fractionMaxSpeed) 
        print 'Tasklist: ', motionProxy.getTaskList()  #prints information about the task
    elif req.method == 2:
        tim = [req.times]
        for t in tim: print(t)                   # prints values of t        times = [[t] for t in req.times]
        isAbsolute = req.isAbsolute
        motionProxy.post.angleInterpolation(names, angles, t, isAbsolute)
        print 'Tasklist: ', motionProxy.getTaskList() #prints information about the task
        taskList = motionProxy.getTaskList()
        uiMotion = taskList[0][1]
        motionProxy.killTask(uiMotion)
        # time.sleep(0.5)

    response_str = "Moving joints."
    
    return response_str
        


if __name__ == '__main__':
    robotIP=str(sys.argv[1])
    PORT=int(sys.argv[2])
    print sys.argv[2]
    motionProxy = ALProxy("ALMotion", robotIP, PORT)
    rospy.init_node('move_joints_server')
    rospy.Service('move_joints', MoveJoints, move_joint_handle)
    rospy.spin()
			
		
