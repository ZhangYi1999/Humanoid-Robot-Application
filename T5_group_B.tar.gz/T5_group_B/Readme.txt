1. Launch the robot with:
	$ roslaunch nao_bringup nao_full_py.launch

2. Run the move_joints server node and the aruco_marker_publisher node with
	$ roslaunch nao_control_tutorial_1 nao.launch

3. Run the robot control client node with
	$ rosrun nao_control_tutorial_1 nao_1 <exercise_number> <tracking_method>

	where <exercise_number> = 1 (for exercise 1.4)
				  2 (for exercise 2.2)
				  3 (for exercise 3)

	<tracking_method> = 0 (when not tracking)
			    1 (for setAngles tracking)
			    2 (for time interpolation tracking)

	e.g. To run exercise 1.4, use the command:
		$ rosrun nao_control_tutorial_1 nao_1 1 0
		
	     To run exercise 3 with setAngles tracking method, use the command:
		$ rosrun nao_control_tutorial_1 nao_1 3 1


*********Group Information*********
Group B members:
Jaime Andrés González Eelman	ge56ruj
Jesús Andrés Varona		ge54cox
Sherif Shousha			ge98law
Wenlan Shen			ge35pin
