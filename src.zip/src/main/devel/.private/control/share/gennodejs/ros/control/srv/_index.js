
"use strict";

let MoveJoints = require('./MoveJoints.js')
let Speech = require('./Speech.js')
let Speak = require('./Speak.js')

module.exports = {
  MoveJoints: MoveJoints,
  Speech: Speech,
  Speak: Speak,
};
