// Auto-generated. Do not edit!

// (in-package control.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SpeakRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.with_motion = null;
      this.motion_name = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('with_motion')) {
        this.with_motion = initObj.with_motion
      }
      else {
        this.with_motion = false;
      }
      if (initObj.hasOwnProperty('motion_name')) {
        this.motion_name = initObj.motion_name
      }
      else {
        this.motion_name = '';
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SpeakRequest
    // Serialize message field [with_motion]
    bufferOffset = _serializer.bool(obj.with_motion, buffer, bufferOffset);
    // Serialize message field [motion_name]
    bufferOffset = _serializer.string(obj.motion_name, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SpeakRequest
    let len;
    let data = new SpeakRequest(null);
    // Deserialize message field [with_motion]
    data.with_motion = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [motion_name]
    data.motion_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.motion_name.length;
    length += object.message.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'control/SpeakRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '074a9d1473ce5dbe3379de93dd95ddf0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    bool with_motion
    string motion_name
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SpeakRequest(null);
    if (msg.with_motion !== undefined) {
      resolved.with_motion = msg.with_motion;
    }
    else {
      resolved.with_motion = false
    }

    if (msg.motion_name !== undefined) {
      resolved.motion_name = msg.motion_name;
    }
    else {
      resolved.motion_name = ''
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

class SpeakResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.done = null;
    }
    else {
      if (initObj.hasOwnProperty('done')) {
        this.done = initObj.done
      }
      else {
        this.done = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SpeakResponse
    // Serialize message field [done]
    bufferOffset = _serializer.bool(obj.done, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SpeakResponse
    let len;
    let data = new SpeakResponse(null);
    // Deserialize message field [done]
    data.done = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'control/SpeakResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '89bb254424e4cffedbf494e7b0ddbfea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    bool done
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SpeakResponse(null);
    if (msg.done !== undefined) {
      resolved.done = msg.done;
    }
    else {
      resolved.done = false
    }

    return resolved;
    }
};

module.exports = {
  Request: SpeakRequest,
  Response: SpeakResponse,
  md5sum() { return '0f35d0853bdf7f8b7aa965fcfc5f5150'; },
  datatype() { return 'control/Speak'; }
};
