#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

static const std::string TOP_WINDOW = "Top camera";
static const std::string COLOR_WINDOW = "Color extraction";
static const std::string BLOB_WINDOW = "Blob extraction";

class ImageConverter
{
     ros::NodeHandle nh_;
     image_transport::ImageTransport it_;
     image_transport::Subscriber image_sub_;
     image_transport::Publisher image_pub_;
   
   public:
     ImageConverter()
       : it_(nh_)
     {
       // Subscrive to input video feed and publish output video feed
       image_sub_ = it_.subscribe("/camera/image_raw", 1, &ImageConverter::imageCb, this);
       image_pub_ = it_.advertise("/image_converter/output_video", 1);
   
       cv::namedWindow(TOP_WINDOW);
       cv::namedWindow(COLOR_WINDOW);
       cv::namedWindow(BLOB_WINDOW);
     }
   
     ~ImageConverter()
     {
       cv::destroyWindow(TOP_WINDOW);
     }
   
     void imageCb(const sensor_msgs::ImageConstPtr& msg)
     {
       cv_bridge::CvImagePtr cv_ptr;
       cv::Mat hsv_image;
       cv::Mat red_image;
       cv::Mat green_image;
       cv::Mat blue_image;
       cv::Mat dilate_image;
       cv::Mat blob_image;


       try
       {
         cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
       }
       catch (cv_bridge::Exception& e)
       {
         ROS_ERROR("cv_bridge exception: %s", e.what());
         return;
       }
       
       // convert BGR image to HSV image
       cv::cvtColor(cv_ptr->image, hsv_image, cv::COLOR_BGR2HSV);

       // extract red green and blue pixels
       cv::inRange(hsv_image, cv::Scalar(150,103,170), cv::Scalar(190,255,255), red_image);
       cv::inRange(hsv_image, cv::Scalar(35,45,46), cv::Scalar(77,255,255), green_image);
       cv::inRange(hsv_image, cv::Scalar(100,43,46), cv::Scalar(124,255,255), blue_image);
       
       // blob
       cv::dilate(cv_ptr->image, dilate_image, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)));
       cv::erode(dilate_image, blob_image, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)));

       // Update GUI Window
       cv::imshow(TOP_WINDOW, cv_ptr->image);
       cv::imshow(COLOR_WINDOW, red_image);
       cv::imshow(BLOB_WINDOW, blob_image);
       cv::waitKey(3);


   
       // Output modified video stream
       image_pub_.publish(cv_ptr->toImageMsg());
     }
   };
   
   int main(int argc, char** argv)
   {
     ros::init(argc, argv, "image_converter");
     ImageConverter ic;
     ros::spin();
     return 0;
   }