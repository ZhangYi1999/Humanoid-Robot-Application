touch passwd
----
基于Nao Robot头部触摸传感器（三段触摸区域，Head/Touch/Front、Head/Touch/Middle、Head/Touch/Rear），设计一个密码功能，只有依次触摸响应区域若干次，才能够验证成功；

为了防止机器人触摸不灵敏或输出错误，还添加后退、复位、确认等功能按钮。

用于机器人触摸事件的编程练习；

