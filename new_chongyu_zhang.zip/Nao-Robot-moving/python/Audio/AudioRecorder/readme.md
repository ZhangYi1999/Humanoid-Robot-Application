ALAudioRecorder
===
Nao机器人录音模块；
可以录音成*"wav" / "OGG"*格式；

##Performances and Limitations

* four channels 48000Hz in OGG.
* four channels 48000Hz in WAV.
* one channels (front, rear, left or right), 16000Hz, in OGG.
* one channels (front, rear, left or right), 16000Hz, in WAV.

