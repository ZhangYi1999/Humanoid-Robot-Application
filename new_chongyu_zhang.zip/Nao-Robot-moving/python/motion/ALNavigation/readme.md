ALNavigation
====

**ALNavigation** API allows the user to perform safe displacements when using the robot.

for Nao:   
The robot cannot yet avoid obstacles, but it is able to move cautiously, stopping as soon as an obstacle enters its security zone.

While moving, the robot tries to detect obstacles in its move direction, using all its sensors.

对于Nao机器人，ALNavigation模块没有提供Method，只有几个Event；
