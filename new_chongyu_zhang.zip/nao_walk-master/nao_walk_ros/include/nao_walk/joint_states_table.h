#ifndef JOINT_STATES_TABLE_H
#define JOINT_STATES_TABLE_H

#include<vector>
#include<string>

extern const std::vector<std::string>joint_state_names;

#endif
